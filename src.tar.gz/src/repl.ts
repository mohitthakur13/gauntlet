import readline, { type Interface as ReadlineInterface } from 'node:readline';
import process from 'node:process';
import { DEFAULT_MODEL_IDS, getPrimaryAndSecondaryIds, MODEL_CONFIGS, resolveModelAddress } from './config.js';
import { loadContext } from './context.js';
import { parseCommand, resolveLoadedInput, saveHistory } from './commands.js';
import { ConversationHistory } from './history.js';
import { Renderer } from './renderer.js';
import type { ContextResolver, ModelClient, ModelId, ModelRole, ReplState } from './types.js';

type PromptPhase = 'prompt' | 'confirming';

function question(
  rl: ReadlineInterface,
  prompt: string,
  setPendingFinish?: (finish: (() => void) | null) => void,
): Promise<string | null> {
  return new Promise((resolve) => {
    let settled = false;

    const finish = (value: string | null): void => {
      if (settled) {
        return;
      }
      settled = true;
      setPendingFinish?.(null);
      (rl as unknown as { removeListener: (event: string, listener: () => void) => void }).removeListener('close', onClose);
      resolve(value);
    };

    const onClose = (): void => finish(null);

    setPendingFinish?.(() => finish(null));
    (rl as unknown as { on: (event: string, listener: () => void) => void }).on('close', onClose);
    rl.question(prompt, (answer) => finish(answer));
  });
}

export async function startRepl(params: {
  cwd: string;
  resolver: ContextResolver;
  clients: Map<ModelId, ModelClient>;
}): Promise<void> {
  const renderer = new Renderer();
  const history = new ConversationHistory();
  let context = await loadContext(params.resolver);
  let replState: ReplState = {
    mode: 'both',
    order: 'primary-first',
    activeModelId: DEFAULT_MODEL_IDS.primaryId,
    hasHistory: false,
    isStreaming: false,
    streamingTarget: null,
  };
  let phase: PromptPhase = 'prompt';
  let abortController: AbortController | null = null;
  let pendingPromptFinish: (() => void) | null = null;
  let exitRequested = false;
  let exiting = false;
  let closed = false;

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: process.stdin.isTTY,
  });

  const confirm = async (prompt: string): Promise<string> => {
    phase = 'confirming';
    try {
      return ((await question(rl, prompt)) ?? '').trim();
    } finally {
      phase = 'prompt';
    }
  };

  const saveIfRequested = async (): Promise<boolean> => {
    if (!replState.hasHistory || !history.hasUnsavedChanges()) {
      return true;
    }

    const answer = await confirm(`Session has ${history.count()} turns. Save before exiting? [y/n/path] `);
    if (!answer || answer.toLowerCase() === 'n') {
      return true;
    }

    try {
      const savedPath = await saveHistory(history, params.cwd, answer.toLowerCase() === 'y' ? undefined : answer);
      renderer.info(`Saved session to ${savedPath}`);
      return true;
    } catch (error) {
      renderer.error(`Failed to save session: ${error instanceof Error ? error.message : String(error)}`);
      return false;
    }
  };

  const handleExit = async (): Promise<void> => {
    if (exiting) {
      return;
    }
    exiting = true;
    exitRequested = false;
    const okayToExit = await saveIfRequested();
    if (!okayToExit) {
      exiting = false;
      return;
    }
    rl.close();
  };

  const onSigint = (): void => {
    if (replState.isStreaming) {
      abortController?.abort();
      replState = { ...replState, isStreaming: false, streamingTarget: null };
      return;
    }
    if (phase === 'confirming') {
      return;
    }

    if (pendingPromptFinish) {
      exitRequested = true;
      pendingPromptFinish();
      return;
    }

    void handleExit();
  };

  rl.on('close', () => {
    closed = true;
  });

  process.on('SIGINT', onSigint);

  renderer.banner(context.path, [...params.clients.values()], replState);

  while (!closed) {
    phase = 'prompt';
    const rawInput = await question(rl, renderer.renderPrompt(replState, DEFAULT_MODEL_IDS, params.clients), (finish) => {
      pendingPromptFinish = finish;
    });
    if (rawInput === null) {
      if (exitRequested) {
        await handleExit();
      }
      break;
    }

    const input = rawInput.trim();
    if (!input) {
      continue;
    }

    const directAddress = parseDirectAddress(input);
    if (directAddress) {
      if (directAddress.type === 'unknown') {
        renderer.error(`Unknown model "${directAddress.token}". Available: ${MODEL_CONFIGS.map((entry) => `@${entry.id}`).join(', ')}`);
        continue;
      }

      if (!directAddress.message) {
        renderer.error(`Usage: @${directAddress.token} <message>`);
        continue;
      }

      await runTurn(directAddress.message, directAddress.modelId);
      continue;
    }

    const command = parseCommand(input, {
      cwd: params.cwd,
      repl: replState,
      context,
      historyLength: history.count(),
      models: MODEL_CONFIGS,
      defaults: DEFAULT_MODEL_IDS,
    });

    if (command.type !== 'noop') {
      if (command.type === 'mode') {
        replState =
          command.mode === 'both'
            ? { ...replState, mode: 'both', activeModelId: DEFAULT_MODEL_IDS.primaryId }
            : { ...replState, mode: 'single', activeModelId: command.modelId };
        renderer.info(command.message);
        continue;
      }

      if (command.type === 'order') {
        if (command.order) {
          replState = { ...replState, order: command.order };
        }
        renderer.info(command.message);
        continue;
      }

      if (command.type === 'info') {
        renderer.info(command.message);
        continue;
      }

      if (command.type === 'context-reload') {
        context = await loadContext(params.resolver);
        renderer.info(context.path ? `Context reloaded: ${context.path}` : 'No context loaded.');
        continue;
      }

      if (command.type === 'clear') {
        const answer = await confirm('Clear history? [y/n] ');
        if (answer.toLowerCase() === 'y') {
          history.clear();
          replState = { ...replState, hasHistory: false };
          renderer.info('History cleared.');
        }
        continue;
      }

      if (command.type === 'save') {
        try {
          const savedPath = await saveHistory(history, params.cwd, command.path);
          renderer.info(`Saved session to ${savedPath}`);
        } catch (error) {
          renderer.error(`Failed to save session: ${error instanceof Error ? error.message : String(error)}`);
        }
        continue;
      }

      if (command.type === 'exit') {
        await handleExit();
        break;
      }

      if (command.type === 'input') {
        try {
          const loaded = await resolveLoadedInput(params.cwd, command.display);
          await runTurn(loaded);
        } catch (error) {
          renderer.error(`Failed to load file: ${error instanceof Error ? error.message : String(error)}`);
        }
        continue;
      }
    }

    await runTurn(rawInput);
  }

  process.removeListener('SIGINT', onSigint);
  process.stdout.write('\n');

  async function runTurn(message: string, directTarget?: ModelId): Promise<void> {
    history.addUserMessage(message);
    replState = { ...replState, hasHistory: true };

    if (directTarget) {
      const client = params.clients.get(directTarget);
      if (!client) {
        renderer.error(`Unknown model "${directTarget}".`);
        renderer.separator();
        return;
      }
      const text = await streamModel(directTarget, client, getRoleForModel(directTarget));
      if (text !== null) {
        history.addAssistantMessage(directTarget, text);
      }
      renderer.separator();
      return;
    }

    if (replState.mode === 'single' && replState.activeModelId) {
      const client = params.clients.get(replState.activeModelId);
      if (!client) {
        renderer.error(`Unknown model "${replState.activeModelId}".`);
        renderer.separator();
        return;
      }
      const text = await streamModel(replState.activeModelId, client, 'freeform');
      if (text !== null) {
        history.addAssistantMessage(replState.activeModelId, text);
      }
      renderer.separator();
      return;
    }

    const [firstId, secondId] = getPrimaryAndSecondaryIds(replState.order);
    const firstClient = params.clients.get(firstId);
    const secondClient = params.clients.get(secondId);
    if (!firstClient || !secondClient) {
      renderer.error('Default model configuration is invalid.');
      renderer.separator();
      return;
    }

    const sequence: Array<{ id: ModelId; client: ModelClient; role: ModelRole }> = [
      { id: firstId, client: firstClient, role: 'proposer' },
      { id: secondId, client: secondClient, role: 'critic' },
    ];

    for (const step of sequence) {
      const text = await streamModel(step.id, step.client, step.role);
      if (text === null) {
        renderer.separator();
        return;
      }
      history.addAssistantMessage(step.id, text);
    }

    renderer.separator();
  }

  async function streamModel(modelId: ModelId, client: ModelClient, role: ModelRole): Promise<string | null> {
    renderer.print('');
    replState = { ...replState, isStreaming: true, streamingTarget: modelId };
    renderer.print(renderer.renderPrompt(replState, DEFAULT_MODEL_IDS, params.clients));
    renderer.print(renderer.modelHeader(client, DEFAULT_MODEL_IDS));

    abortController = new AbortController();

    try {
      const result = await client.streamResponse({
        history: history.getEntries(),
        context: context.content,
        role,
        signal: abortController.signal,
        write: (chunk) => renderer.write(chunk),
      });
      renderer.print('');

      if (result.cancelled) {
        renderer.info('[cancelled]');
        return null;
      }

      return result.text.trimEnd();
    } catch (error) {
      if (error instanceof Error && error.message.startsWith(`${client.displayName} error:`)) {
        if (error.message.includes('429')) {
          renderer.error(`${error.message} — retrying in 5s failed`);
        } else {
          renderer.error(error.message);
        }
      } else {
        renderer.error(`${client.displayName} error: ${error instanceof Error ? error.message : String(error)}`);
      }
      return null;
    } finally {
      abortController = null;
      replState = { ...replState, isStreaming: false, streamingTarget: null };
    }
  }

  function getRoleForModel(modelId: ModelId): ModelRole {
    if (replState.mode !== 'both') {
      return 'freeform';
    }

    if (replState.order === 'primary-first') {
      if (modelId === DEFAULT_MODEL_IDS.primaryId) {
        return 'proposer';
      }
      if (modelId === DEFAULT_MODEL_IDS.secondaryId) {
        return 'critic';
      }
      return 'freeform';
    }

    if (modelId === DEFAULT_MODEL_IDS.secondaryId) {
      return 'proposer';
    }
    if (modelId === DEFAULT_MODEL_IDS.primaryId) {
      return 'critic';
    }
    return 'freeform';
  }
}

function parseDirectAddress(
  input: string,
): { type: 'target'; modelId: ModelId; message: string; token: string } | { type: 'unknown'; token: string } | null {
  const match = input.match(/^@([^\s]+)\s*(.*)$/i);
  if (!match) {
    return null;
  }

  const [, rawToken, rest] = match;
  const modelId = resolveModelAddress(rawToken);
  if (!modelId) {
    return { type: 'unknown', token: rawToken };
  }

  return {
    type: 'target',
    modelId,
    message: rest.trim(),
    token: rawToken,
  };
}
