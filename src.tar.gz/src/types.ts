export type ActiveMode = 'both' | 'single';

export type ActiveOrder = 'primary-first' | 'secondary-first';

export type ModelId = string;

export interface ReplState {
  mode: ActiveMode;
  order: ActiveOrder;
  activeModelId: ModelId | null;
  hasHistory: boolean;
  isStreaming: boolean;
  streamingTarget?: ModelId | null;
}

export type ModelRole = 'proposer' | 'critic' | 'freeform';

export type HistoryRole = 'user' | 'assistant';

export interface HistoryEntry {
  role: HistoryRole;
  content: string;
  author: 'you' | ModelId;
  timestamp: string;
}

export interface ContextState {
  path: string | null;
  content: string;
}

export interface ContextResolver {
  explicitPath?: string;
  cwd: string;
}

export interface StreamResult {
  text: string;
  cancelled: boolean;
  skipped: boolean;
}

export interface ModelClient {
  readonly id: ModelId;
  readonly model: string;
  readonly displayName: string;
  streamResponse(input: {
    history: HistoryEntry[];
    context: string;
    role: ModelRole;
    signal: AbortSignal;
    write: (chunk: string) => void;
  }): Promise<StreamResult>;
}

export interface ModelDefinition {
  id: ModelId;
  model: string;
  displayName: string;
  provider: string;
}

export interface ModelDefaults {
  primaryId: ModelId;
  secondaryId: ModelId;
}

export interface CommandContext {
  cwd: string;
  repl: ReplState;
  context: ContextState;
  historyLength: number;
  models: ModelDefinition[];
  defaults: ModelDefaults;
}

export type CommandResult =
  | { type: 'mode'; mode: 'both'; message: string }
  | { type: 'mode'; mode: 'single'; modelId: ModelId; message: string }
  | { type: 'order'; order?: ActiveOrder; message: string }
  | { type: 'info'; message: string }
  | { type: 'input'; content: string; display: string }
  | { type: 'clear' }
  | { type: 'save'; path?: string }
  | { type: 'context-reload' }
  | { type: 'exit' }
  | { type: 'noop' };
