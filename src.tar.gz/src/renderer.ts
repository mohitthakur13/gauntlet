import process from 'node:process';
import type { ModelClient, ModelDefaults, ModelId, ReplState } from './types.js';

type ColorName = 'reset' | 'dim' | 'red' | 'yellow' | 'cyan' | 'purple' | 'white';

const ANSI: Record<ColorName, string> = {
  reset: '\u001b[0m',
  dim: '\u001b[2m',
  red: '\u001b[31m',
  yellow: '\u001b[33m',
  cyan: '\u001b[36m',
  purple: '\u001b[35m',
  white: '\u001b[37m',
};

export class Renderer {
  private readonly useColor = process.stdout.isTTY;

  color(text: string, color: ColorName): string {
    if (!this.useColor) {
      return text;
    }

    return `${ANSI[color]}${text}${ANSI.reset}`;
  }

  print(text = ''): void {
    process.stdout.write(`${text}\n`);
  }

  write(text: string): void {
    process.stdout.write(text);
  }

  banner(contextPath: string | null, clients: ModelClient[], state: ReplState): void {
    this.print('┌─────────────────────────────────────────┐');
    this.print('│  gauntlet                    ctrl+c/q   │');
    this.print('└─────────────────────────────────────────┘');
    this.print(`Context: ${contextPath ?? 'none'}`);
    this.print(`Models:  ${clients.map((client) => `${client.displayName} (${client.model})`).join('  ·  ')}`);
    this.print(`Mode:    ${state.mode}`);
    this.separator();
  }

  separator(): void {
    this.print(this.color('──────────────────────────────────────────', 'dim'));
  }

  renderPrompt(state: ReplState, defaults: ModelDefaults, clients: Map<ModelId, ModelClient>): string {
    if (state.isStreaming) {
      if (!state.streamingTarget) {
        return this.color('[streaming...]', 'dim');
      }

      return `${this.color('[', 'cyan')}${this.color('→', 'dim')} ${this.color(this.getDisplayName(state.streamingTarget, clients), 'cyan')}${this.color(']', 'cyan')} ${this.color('streaming...', 'dim')}`;
    }

    if (state.mode === 'single' && state.activeModelId) {
      return `${this.color(`[${this.getDisplayName(state.activeModelId, clients)}]`, 'cyan')} ${this.color('›', 'white')} `;
    }

    const primary = this.getDisplayName(defaults.primaryId, clients);
    const secondary = this.getDisplayName(defaults.secondaryId, clients);
    const label = state.order === 'primary-first'
      ? `${this.color(`[${primary} `, 'cyan')}${this.color('→', 'dim')}${this.color(` ${secondary}]`, 'cyan')}`
      : `${this.color(`[${secondary} `, 'cyan')}${this.color('→', 'dim')}${this.color(` ${primary}]`, 'cyan')}`;

    return `${label} ${this.color('›', 'white')} `;
  }

  modelHeader(client: ModelClient, defaults: ModelDefaults): string {
    const color = client.id === defaults.primaryId ? 'cyan' : client.id === defaults.secondaryId ? 'purple' : 'white';
    const label = this.color(client.displayName, color);
    const line = client.id === defaults.primaryId ? '──────────────────────────────────────' : '───────────────────────────────────────';
    return `${label} ${this.color(line, 'dim')}`;
  }

  private getDisplayName(id: ModelId, clients: Map<ModelId, ModelClient>): string {
    return clients.get(id)?.displayName ?? id;
  }

  info(message: string): void {
    this.print(this.color(message, 'yellow'));
  }

  error(message: string): void {
    this.print(this.color(message, 'red'));
  }
}
