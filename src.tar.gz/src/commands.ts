import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { getModelDisplayName } from './config.js';
import { previewContext } from './context.js';
import { ConversationHistory } from './history.js';
import type { ActiveOrder, CommandContext, CommandResult } from './types.js';

function formatOrder(order: ActiveOrder, primaryId: string, secondaryId: string): string {
  return order === 'primary-first'
    ? `Order: ${getModelDisplayName(primaryId)} → ${getModelDisplayName(secondaryId)}`
    : `Order: ${getModelDisplayName(secondaryId)} → ${getModelDisplayName(primaryId)}`;
}

export function parseCommand(input: string, context: CommandContext): CommandResult {
  const trimmed = input.trim();
  if (!trimmed.startsWith('/')) {
    return { type: 'noop' };
  }

  const [command, ...rest] = trimmed.split(/\s+/);
  const arg = rest.join(' ');
  const { primaryId, secondaryId } = context.defaults;
  const targetModel = context.models.find((entry) => command === `/${entry.id}`);

  if (targetModel) {
    return {
      type: 'mode',
      mode: 'single',
      modelId: targetModel.id,
      message: `Mode set to ${targetModel.displayName}.`,
    };
  }

  switch (command) {
    case '/both':
      return { type: 'mode', mode: 'both', message: 'Mode set to both.' };
    case '/order':
      if (context.repl.mode !== 'both') {
        return {
          type: 'info',
          message: 'Order only applies in /both mode. Switch with /both first.',
        };
      }

      if (!arg) {
        return { type: 'order', message: formatOrder(context.repl.order, primaryId, secondaryId) };
      }

      if (arg !== 'primary-first' && arg !== 'secondary-first') {
        return { type: 'info', message: 'Usage: /order primary-first|secondary-first' };
      }

      return { type: 'order', order: arg, message: formatOrder(arg, primaryId, secondaryId) };
    case '/load':
      if (!arg) {
        return { type: 'info', message: 'Usage: /load <path>' };
      }
      return { type: 'input', content: `@load ${arg}`, display: arg };
    case '/context':
      if (arg === 'reload') {
        return { type: 'context-reload' };
      }
      return { type: 'info', message: previewContext(context.context) };
    case '/clear':
      return { type: 'clear' };
    case '/save':
      return { type: 'save', path: arg || undefined };
    case '/models':
      return {
        type: 'info',
        message: context.models.map((entry) => `${entry.id}: ${entry.model}`).join('\n'),
      };
    case '/help':
      return {
        type: 'info',
        message: [
          'Routing',
          ...context.models.map((entry) => `  /${entry.id}              Only ${entry.displayName} responds`),
          '  /both               Both models respond (default)',
          `  /order primary-first    ${getModelDisplayName(primaryId)} responds first, ${getModelDisplayName(secondaryId)} critiques`,
          `  /order secondary-first  ${getModelDisplayName(secondaryId)} responds first, ${getModelDisplayName(primaryId)} critiques`,
          '',
          'Input',
          '  /load <path>        Load a file as the next user message',
          '  /context            Show loaded context file',
          '  /context reload     Reload context.md from disk',
          '',
          'Session',
          '  /save [path]        Save session to markdown',
          '  /clear              Clear conversation history',
          '  /models             Show current model names',
          '',
          'Utility',
          '  /help               Show this help',
          '  /exit or /q         Exit gauntlet',
        ].join('\n'),
      };
    case '/exit':
    case '/q':
      return { type: 'exit' };
    default:
      return { type: 'info', message: `Unknown command: ${command}` };
  }
}

export async function resolveLoadedInput(cwd: string, relativePath: string): Promise<string> {
  const absolutePath = path.resolve(cwd, relativePath);
  return readFile(absolutePath, 'utf8');
}

export async function saveHistory(history: ConversationHistory, cwd: string, targetPath?: string): Promise<string> {
  const timestamp = new Date().toISOString().replaceAll(':', '-');
  const resolvedPath = path.resolve(cwd, targetPath ?? `gauntlet-session-${timestamp}.md`);
  const content = history
    .getEntries()
    .map((entry) => {
      const label = entry.author === 'you' ? 'You' : entry.author;
      return `## ${label}\n\n_${entry.timestamp}_\n\n${entry.content}\n`;
    })
    .join('\n');

  await writeFile(resolvedPath, content, 'utf8');
  history.markSaved();
  return resolvedPath;
}
