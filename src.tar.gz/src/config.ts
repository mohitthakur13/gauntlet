import process from 'node:process';
import configData from './config.json' with { type: 'json' };
import { CodexClient } from './models/codex.js';
import { OpusClient } from './models/opus.js';
import type { ModelClient, ModelDefaults, ModelDefinition, ModelId } from './types.js';

export const MODEL_CONFIGS: ModelDefinition[] = configData.models;
export const DEFAULT_MODEL_IDS: ModelDefaults = configData.defaults;

const MODEL_CONFIG_BY_ID = new Map(MODEL_CONFIGS.map((entry) => [entry.id, entry]));

const PROVIDERS: Record<string, (entry: ModelDefinition, apiKey: string) => ModelClient> = {
  openai: (entry, apiKey) => new CodexClient(entry.id, entry.model, entry.displayName, apiKey),
  anthropic: (entry, apiKey) => new OpusClient(entry.id, entry.model, entry.displayName, apiKey),
};

function getApiKey(provider: string): string {
  if (provider === 'openai') {
    return process.env.OPENAI_API_KEY ?? '';
  }

  if (provider === 'anthropic') {
    return process.env.ANTHROPIC_API_KEY ?? '';
  }

  return '';
}

function validateConfig(): void {
  const ids = new Set(MODEL_CONFIGS.map((entry) => entry.id));
  if (!ids.has(DEFAULT_MODEL_IDS.primaryId)) {
    throw new Error(`Unknown primary model id: ${DEFAULT_MODEL_IDS.primaryId}`);
  }
  if (!ids.has(DEFAULT_MODEL_IDS.secondaryId)) {
    throw new Error(`Unknown secondary model id: ${DEFAULT_MODEL_IDS.secondaryId}`);
  }
}

export function createClients(): Map<ModelId, ModelClient> {
  validateConfig();

  const clients = new Map<ModelId, ModelClient>();
  for (const entry of MODEL_CONFIGS) {
    const factory = PROVIDERS[entry.provider];
    if (!factory) {
      throw new Error(`Unknown provider: ${entry.provider}`);
    }
    clients.set(entry.id, factory(entry, getApiKey(entry.provider)));
  }

  return clients;
}

export function getModelConfig(id: ModelId): ModelDefinition {
  const entry = MODEL_CONFIG_BY_ID.get(id);
  if (!entry) {
    throw new Error(`Unknown model id: ${id}`);
  }
  return entry;
}

export function getModelDisplayName(id: ModelId): string {
  return getModelConfig(id).displayName;
}

export function resolveModelAddress(token: string): ModelId | null {
  const normalized = token.trim().toLowerCase();
  if (!normalized) {
    return null;
  }

  for (const entry of MODEL_CONFIGS) {
    if (normalized === entry.id.toLowerCase() || normalized === entry.displayName.toLowerCase()) {
      return entry.id;
    }
  }

  return null;
}

export function getPrimaryAndSecondaryIds(order: 'primary-first' | 'secondary-first'): [ModelId, ModelId] {
  return order === 'primary-first'
    ? [DEFAULT_MODEL_IDS.primaryId, DEFAULT_MODEL_IDS.secondaryId]
    : [DEFAULT_MODEL_IDS.secondaryId, DEFAULT_MODEL_IDS.primaryId];
}
